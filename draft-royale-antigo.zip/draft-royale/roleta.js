let configs = JSON.parse(localStorage.getItem('draftRoyaleConfig')) || { casas: 10, modo: 'aleatorio' };
let tipos = configs.tiposPergunta || ['individual_avanco', 'individual_recuo', 'coletiva'];

// Verificação inteligente: se o modo contiver "duelo" ou "escolha", ativa o modo de seleção com 3 opções
let modoAtual = (configs.modo || '').toLowerCase();
let modoJogo = (modoAtual.includes('duelo') || modoAtual.includes('escolha')) ? 'duelo' : 'normal';

let hasAvancoInd = tipos.includes('individual_avanco');
let hasRecuoInd = tipos.includes('individual_recuo');
let hasColetiva = tipos.includes('coletiva');

let posicoes = JSON.parse(localStorage.getItem('draftRoyalePosicoes')) || {};
let casasTotal = configs.casas || 10;
let progressoMaximo = 0;
for (let jog in posicoes) {
    if (posicoes[jog] > progressoMaximo) {
        progressoMaximo = posicoes[jog];
    }
}
let atingiu30PorCento = (progressoMaximo / casasTotal) >= 0.3;

let fatias = [];
let contextoModo = ''; 

if (hasAvancoInd && hasRecuoInd && hasColetiva) {
    fatias = ['A','A','A','A', 'R','R', 'C','C','C','C']; 
    contextoModo = 'todos';
} else if (hasAvancoInd && hasColetiva && !hasRecuoInd) {
    fatias = ['A','A','A','A','A','A', 'C','C','C','C']; 
    contextoModo = 'avanco_coletivo';
} else if (hasRecuoInd && hasColetiva && !hasAvancoInd) {
    fatias = ['R','R', 'C','C','C','C','C','C','C','C']; 
    contextoModo = 'recuo_coletivo';
} else if (hasAvancoInd && hasRecuoInd && !hasColetiva) {
    fatias = ['A','A','A','A','A','A','A','A', 'R','R']; 
    contextoModo = 'somente_individuais';
} else {
    fatias = ['A','A','A','A', 'R','R', 'C','C','C','C']; 
    contextoModo = 'todos';
}

if (!atingiu30PorCento) {
    fatias = fatias.map(fatia => fatia === 'R' ? 'A' : fatia);
}

fatias = fatias.sort(() => Math.random() - 0.5);

let rotacaoAtual = 0;
let girando = false;

document.addEventListener("DOMContentLoaded", () => {
    const roda = document.getElementById('roda');
    let gradientString = 'from -18deg, '; 
    let corAtual = '';

    fatias.forEach((tipo, index) => {
        if (tipo === 'A') corAtual = '#4CAF50'; 
        if (tipo === 'R') corAtual = '#F44336'; 
        if (tipo === 'C') corAtual = '#2196F3'; 
        
        let inicio = index * 36;
        let fim = (index + 1) * 36;
        gradientString += `${corAtual} ${inicio}deg ${fim}deg${index < 9 ? ', ' : ''}`;
    });

    roda.style.background = `conic-gradient(${gradientString})`;
});

function girarRoleta() {
    if (girando) return;
    girando = true;
    
    const btn = document.getElementById('btn-girar');
    const roda = document.getElementById('roda');
    btn.disabled = true;
    btn.innerText = "GIRANDO...";

    const fatiaVencedoraIndex = Math.floor(Math.random() * 10);
    const tipoVencedor = fatias[fatiaVencedoraIndex];

    const voltasExtras = 360 * 5;
    const rotacaoParaFatia = 360 - (fatiaVencedoraIndex * 36);
    const novaRotacao = rotacaoAtual + voltasExtras + rotacaoParaFatia;

    roda.style.transform = `rotate(${novaRotacao}deg)`;
    rotacaoAtual = novaRotacao - (novaRotacao % 360); 

    setTimeout(() => {
        revelarResultado(tipoVencedor);
    }, 5000);
}

function revelarResultado(tipo) {
    const caixa = document.getElementById('caixa-resultado');
    const txtAviso = document.getElementById('texto-aviso');
    const txtEfeito = document.getElementById('texto-efeito');
    const opcoesContainer = document.getElementById('opcoes-container');
    const btn = document.getElementById('btn-girar');

    caixa.className = 'resultado-box';
    opcoesContainer.innerHTML = '';
    opcoesContainer.style.display = 'none';

    const metade = Math.floor(perguntasIndividuais.length / 2);
    const listaIndividuaisAvanco = perguntasIndividuais.slice(0, metade);
    const listaIndividuaisRecuo = perguntasIndividuais.slice(metade);

    if (modoJogo === 'duelo') {
        // --- MODO DUELO TÁTICO (Com escolhas de 3 opções) ---
        let opcoesParaEscolher = [];
        let tituloEfeito = "";

        if (tipo === 'A') {
            tituloEfeito = "ESCOLHA UM AVANÇO INDIVIDUAL";
            caixa.classList.add('efeito-avanco');
            opcoesParaEscolher = embaralhar(listaIndividuaisAvanco).slice(0, 3).map(p => ({ ...p, tipoEfeito: 'AVANÇO', classeTag: 'tag-avanco' }));
        } 
        else if (tipo === 'R') {
            tituloEfeito = "ESCOLHA UM RECUO INDIVIDUAL";
            caixa.classList.add('efeito-recuo');
            opcoesParaEscolher = embaralhar(listaIndividuaisRecuo).slice(0, 3).map(p => ({ ...p, tipoEfeito: 'RECUO', classeTag: 'tag-recuo' }));
        } 
        else if (tipo === 'C') {
            tituloEfeito = "ESCOLHA O DESAFIO COLETIVO";
            caixa.classList.add('efeito-avanco');
            
            const metadeColetiva = Math.floor(perguntasColetivas.length / 2);
            const coletivasAvanco = perguntasColetivas.slice(0, metadeColetiva);
            const coletivasRecuo = perguntasColetivas.slice(metadeColetiva);

            let escolhidasAv = embaralhar(coletivasAvanco).slice(0, 2).map(p => ({ ...p, tipoEfeito: 'AVANÇO COLETIVO', classeTag: 'tag-avanco' }));
            let escolhidasRe = (!atingiu30PorCento) ? [] : embaralhar(coletivasRecuo).slice(0, 1).map(p => ({ ...p, tipoEfeito: 'RECUO COLETIVO', classeTag: 'tag-recuo' }));
            
            while (escolhidasAv.length + escolhidasRe.length < 3) {
                let extra = embaralhar(coletivasAvanco)[0];
                if (!escolhidasAv.some(e => e.texto === extra.texto)) {
                    escolhidasAv.push({ ...extra, tipoEfeito: 'AVANÇO COLETIVO', classeTag: 'tag-avanco' });
                }
            }

            opcoesParaEscolher = embaralhar([...escolhidasAv, ...escolhidasRe]);
        }

        txtAviso.innerText = "Clique em uma das opções abaixo para definir a regra do turno:";
        txtEfeito.innerText = tituloEfeito;
        opcoesContainer.style.display = 'flex';
        btn.style.display = 'none';

        opcoesParaEscolher.forEach(opcao => {
            let btnOpcao = document.createElement('button');
            btnOpcao.className = 'btn-opcao-duelo';
            btnOpcao.innerHTML = `<span class="tag-tipo ${opcao.classeTag}">${opcao.tipoEfeito}</span> ${opcao.texto}`;
            
            btnOpcao.onclick = () => {
                localStorage.setItem('draftRoyalePerguntaEscolhida', JSON.stringify({
                    texto: opcao.texto,
                    efeito: opcao.tipoEfeito
                }));
                window.location.href = "resultados.html";
            };
            opcoesContainer.appendChild(btnOpcao);
        });

    } else {
        // --- MODO CAOS ALEATÓRIO (Automático tradicional) ---
        let perguntaSorteada = "";
        let classeCor = "";
        let efeitoTexto = "";

        if (tipo === 'A') {
            perguntaSorteada = listaIndividuaisAvanco[Math.floor(Math.random() * listaIndividuaisAvanco.length)].texto;
            classeCor = 'efeito-avanco';
            efeitoTexto = "+ AVANÇO INDIVIDUAL +";
        } 
        else if (tipo === 'R') {
            perguntaSorteada = listaIndividuaisRecuo[Math.floor(Math.random() * listaIndividuaisRecuo.length)].texto;
            classeCor = 'efeito-recuo';
            efeitoTexto = "- RECUO INDIVIDUAL -";
        } 
        else if (tipo === 'C') {
            let chanceRoll = Math.random() * 100;
            let seraAvanco = true;
            if (!atingiu30PorCento) {
                seraAvanco = true;
            } else {
                if (contextoModo === 'todos' || contextoModo === 'avanco_coletivo') {
                    seraAvanco = chanceRoll <= 62.5; 
                } else if (contextoModo === 'recuo_coletivo') {
                    seraAvanco = chanceRoll <= 81.25; 
                }
            }
            perguntaSorteada = perguntasColetivas[Math.floor(Math.random() * perguntasColetivas.length)].texto;
            if (seraAvanco) {
                classeCor = 'efeito-avanco';
                efeitoTexto = "+ AVANÇO COLETIVO +";
            } else {
                classeCor = 'efeito-recuo';
                efeitoTexto = "- RECUO COLETIVO -";
            }
        }

        caixa.classList.add(classeCor);
        txtAviso.innerText = perguntaSorteada;
        txtEfeito.innerText = efeitoTexto;

        btn.disabled = false;
        btn.innerText = "VER RESULTADO";
        btn.onclick = () => {
            localStorage.setItem('draftRoyalePerguntaEscolhida', JSON.stringify({
                texto: perguntaSorteada,
                efeito: efeitoTexto.includes("AVANÇO") ? "AVANÇO" : "RECUO"
            }));
            window.location.href = "resultados.html"; 
        };
    }
}

function embaralhar(array) {
    return array.sort(() => Math.random() - 0.5);
}
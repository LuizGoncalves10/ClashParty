let configs = JSON.parse(localStorage.getItem('draftRoyaleConfig')) || { casas: 10, modo: 'aleatorio' };
let nomesJogadores = JSON.parse(localStorage.getItem('draftRoyaleNomes')) || ["Jogador 1", "Jogador 2", "Jogador 3", "Jogador 4"];
let escolhasDaRodada = JSON.parse(localStorage.getItem('draftRoyaleCartasEscolhidas')) || {};
let dadosPergunta = JSON.parse(localStorage.getItem('draftRoyalePerguntaEscolhida')) || { texto: "Desafio Padrão", efeito: "AVANÇO" };

let todasAsTropasGlobais = [];

document.addEventListener("DOMContentLoaded", async () => {
    await carregarTropasParaCalculo();
    processarResultadosRodada();
});

async function carregarTropasParaCalculo() {
    try {
        let resposta = await fetch('../../todas_as_cartas.json');
        let dadosBrutos = await resposta.json();
        todasAsTropasGlobais = dadosBrutos.filter(carta => carta.type && carta.type.toLowerCase() === 'troop');
    } catch (e) {
        console.error("Erro ao carregar base de cartas para o resultado.");
    }
}

function processarResultadosRodada() {
    // 1. Exibe a pergunta e o efeito no topo
    document.getElementById('texto-pergunta-final').innerText = dadosPergunta.texto;
    let badge = document.getElementById('badge-efeito-final');
    
    let isAvanco = dadosPergunta.efeito.toUpperCase().includes("AVANÇO") || dadosPergunta.efeito.toUpperCase().includes("AVANCO");
    badge.innerText = `+ ${dadosPergunta.efeito.toUpperCase()} +`;
    badge.className = `badge-efeito ${isAvanco ? 'badge-verde' : 'badge-vermelho'}`;

    // 2. Monta o array com as cartas de cada jogador
    let cartasDosJogadores = nomesJogadores.map(jogador => {
        let nomeCarta = escolhasDaRodada[jogador];
        let cartaObj = todasAsTropasGlobais.find(t => (t.name_pt || t.name) === nomeCarta) || {};
        return { jogador: jogador, carta: cartaObj, nomeCarta: nomeCarta || "Desconhecida" };
    });

    // 3. Descobre quais jogadores cumpriram a condição da pergunta
    let vencedores = descobrirJogadoresAlvo(dadosPergunta.texto, cartasDosJogadores);

    // 4. Atualiza as posições no tabuleiro armazenadas no localStorage
    let posicoes = JSON.parse(localStorage.getItem('draftRoyalePosicoes')) || {};
    let maxCasas = configs.casas || 10;

    nomesJogadores.forEach(jog => {
        if (posicoes[jog] === undefined) posicoes[jog] = 0;
        if (vencedores.includes(jog)) {
            if (isAvanco) {
                posicoes[jog] = Math.min(maxCasas, posicoes[jog] + 2); // Regra padrão de avanço (ex: 2 casas)
            } else {
                posicoes[jog] = Math.max(0, posicoes[jog] - 1); // Regra padrão de recuo (ex: 1 casa)
            }
        }
    });
    localStorage.setItem('draftRoyalePosicoes', JSON.stringify(posicoes));

    // 5. Renderiza a Tabela de Classificação
    renderizarTabela(cartasDosJogadores, vencedores, isAvanco, dadosPergunta.texto);

    // 6. Configura o botão inferior de acordo com o modo de jogo
    configurarBotaoProximo();
}

// Encontra quais jogadores foram atingidos pela regra da pergunta
function descobrirJogadoresAlvo(textoPergunta, cartasDosJogadores) {
    // Procura nas individuais
    let acheiInd = perguntasIndividuais.find(p => p.texto === textoPergunta);
    if (acheiInd) {
        return acheiInd.checar(cartasDosJogadores);
    }
    // Procura nas coletivas
    let acheiCol = perguntasColetivas.find(p => p.texto === textoPergunta);
    if (acheiCol) {
        return acheiCol.checar(cartasDosJogadores);
    }
    return [];
}

// Preenche a tabela ordenando os alvos no topo
function renderizarTabela(cartasDosJogadores, vencedores, isAvanco, textoPergunta) {
    let tbody = document.getElementById('corpo-tabela-ranking');
    tbody.innerHTML = '';

    // Ordena colocando quem foi atingido no topo
    cartasDosJogadores.sort((a, b) => {
        let aVenceu = vencedores.includes(a.jogador) ? 0 : 1;
        let bVenceu = vencedores.includes(b.jogador) ? 0 : 1;
        return aVenceu - bVenceu;
    });

    cartasDosJogadores.forEach((item, index) => {
        let tr = document.createElement('tr');
        let atingido = vencedores.includes(item.jogador);

        if (atingido) {
            tr.className = isAvanco ? 'linha-destaque-verde' : 'linha-destaque-vermelho';
        }

        // Extrai um valor representativo da carta para exibir na pontuação
        let pontuadorTexto = extrairPontuador(item.carta, textoPergunta);

        tr.innerHTML = `
            <td>#${index + 1}</td>
            <td>${item.jogador} ${atingido ? (isAvanco ? '🟢' : '🔴') : ''}</td>
            <td>${item.nomeCarta}</td>
            <td>${pontuadorTexto}</td>
        `;
        tbody.appendChild(tr);
    });
}

function extrairPontuador(carta, texto) {
    if (!carta || Object.keys(carta).length === 0) return 'N/A';
    t = texto.toLowerCase();
    if (t.includes('dano') && !t.includes('segundo') && !t.includes('total')) return `Dano: ${carta.damage || 0}`;
    if (t.includes('vida') && !t.includes('total')) return `HP: ${carta.hp || 0}`;
    if (t.includes('dps') || t.includes('segundo')) return `DPS: ${carta.dps || 0}`;
    if (t.includes('elixir')) return `Elixir: ${carta.elixir || 0}`;
    if (t.includes('raridade')) return `Raridade: ${carta.rarity || 'Comum'}`;
    if (t.includes('arena')) return `Arena: ${carta.arena || 0}`;
    if (t.includes('velocidade')) return `Velocidade: ${carta.speed || 0}`;
    if (t.includes('alcance')) return `Alcance: ${carta.range || 0}`;
    if (t.includes('tropas')) return `Qtd: ${carta.troop_count || 1}`;
    if (t.includes('voadoras') || t.includes('terrestres')) return carta.is_flying ? 'Sim (Voadora)' : 'Sim (Terrestre)';
    return `Atributo Válido`;
}

function configurarBotaoProximo() {
    let btn = document.getElementById('btn-proximo-turno');
    let modoJogo = configs.modo === 'duelo' ? 'duelo' : 'normal';

    if (modoJogo === 'duelo') {
        // No Duelo Tático, define quem joga no próximo turno de escolha
        let indiceAtual = parseInt(localStorage.getItem('draftRoyaleProximoDuelo') || '0');
        let proximoJogador = nomesJogadores[indiceAtual];
        
        btn.innerText = `Passe para ${proximoJogador} (Próximo)`;
        btn.onclick = () => {
            let novoIndice = (indiceAtual + 1) % nomesJogadores.length;
            localStorage.setItem('draftRoyaleProximoDuelo', novoIndice);
            window.location.href = "tabuleiro.html";
        };
    } else {
        // No Caos Aleatório, o botão é apenas "Próximo"
        btn.innerText = "PRÓXIMO";
        btn.onclick = () => {
            window.location.href = "tabuleiro.html";
        };
    }
}